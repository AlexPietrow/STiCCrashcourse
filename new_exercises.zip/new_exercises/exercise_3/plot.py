import matplotlib as m
fig_size = (8,6)
font = 'Helvetica'
params = {'backend': 'tkagg',
          'axes.labelsize': 9,
          'axes.titlesize': 9,
          'font.size': 8,
          'legend.fontsize': 9,
          'font.family': 'sans-serif',
          'font.sans-serif': font,
          'xtick.labelsize': 8,
          'ytick.labelsize': 8,
          'text.usetex': True,
          'figure.figsize': fig_size,
          'figure.dpi': 80,
          'lines.linewidth': 1.0,
          'axes.linewidth':1.0,
          'image.interpolation'  : 'nearest',
          'xtick.major.size'     : 5,      # major tick size in points
          'xtick.minor.size'     : 3.5,      # minor tick size in points
          'xtick.major.width'    : 0.5,    # major tick width in points
          'xtick.minor.width'    : 0.3,    # minor tick width in points
          'axes.spines.top': False,
          'axes.spines.right':False,
          'xtick.top': False,
          'ytick.right': False,
          'axes.formatter.useoffset': False
}
m.rcParams.update(params)
m.rcParams['text.latex.preamble'] = [
       r'\usepackage{siunitx}',   # i need upright \micro symbols, but you need...
       r'\sisetup{detect-all}',   # ...this to force siunitx to actually use your fonts
       r'\usepackage{helvet}',    # set the normal font here
       r'\usepackage{sansmath}',  # load up the sansmath so that math -> helvet
       r'\sansmath'               # <- tricky! -- gotta actually tell tex to use!
]

m.rcParams['mathtext.fontset'] = 'custom'
m.rcParams['mathtext.rm'] = font
m.rcParams['mathtext.it'] = font+':italic'
m.rcParams['mathtext.bf'] = font+':bold'
m.rcParams['text.latex.preamble'] = [r"\usepackage{amsmath}"]

import sparsetools as sp
import numpy as np
import witt as w
import matplotlib.pyplot as plt
from matplotlib.gridspec import GridSpec
from matplotlib.backends import pylab_setup
_backend_mod, new_figure_manager, draw_if_interactive, _show = pylab_setup()

def my_subplot2grid(fig, shape, loc, rowspan=1, colspan=1, **kwargs):

    s1, s2 = shape
    subplotspec = GridSpec(s1, s2).new_subplotspec(loc,
                                                   rowspan=rowspan,
                                                   colspan=colspan)
    a = fig.add_subplot(subplotspec, **kwargs)
    bbox = a.bbox
    byebye = []
    for other in fig.axes:
        if other==a: continue
        if bbox.fully_overlaps(other.bbox):
            byebye.append(other)
    for ax in byebye: delaxes(ax)

    draw_if_interactive()
    return a


def plot_pix(m, o, s, yy, xx):

    f = plt.figure(figsize=(8,8))
    ax = [None]*10
    
    ax[0] = my_subplot2grid(f, (4,2), (0,0), colspan=1, rowspan=1)
    ax[1] = my_subplot2grid(f, (4,2), (0,1), colspan=1, rowspan=1)
    ax[2] = my_subplot2grid(f, (4,2), (1,0), colspan=1, rowspan=1)
    ax[3] = my_subplot2grid(f, (4,2), (1,1), colspan=1, rowspan=1)
    
    ax[4] = my_subplot2grid(f, (4,3), (2,0), colspan=1, rowspan=1)
    ax[5] = my_subplot2grid(f, (4,3), (2,1), colspan=1, rowspan=1)
    ax[6] = my_subplot2grid(f, (4,3), (2,2), colspan=1, rowspan=1)
    ax[7] = my_subplot2grid(f, (4,3), (3,0), colspan=1, rowspan=1)
    ax[8] = my_subplot2grid(f, (4,3), (3,1), colspan=1, rowspan=1)
    ax[9] = my_subplot2grid(f, (4,3), (3,2), colspan=1, rowspan=1)

    w = o.wav-8542.091
    idx = np.where(o.weights[:,0]<1.0)[0]
    ytit = ['I', 'Q', 'U', 'V', 'T [kK]', r'V$_\mathrm{l.o.s}$ [km s$^{-1}$]',r'V$_\mathrm{turb}$ [km s$^{-1}$]', r'B$_\parallel$ [kG]', r'$|$B$_\bot|$ [kG]', r'$\chi$ [deg]' ]

    iax = 0
    for jj in range(2):
        for ii in range(2):
            ax[iax].plot(w[idx], o.dat[0,yy,xx,idx,iax], '+-', color='orangered', label='obs')
            ax[iax].plot(w, s.dat[0,yy,xx,:,iax], '-', color='black', label='inv')
            ax[iax].set_ylabel(ytit[iax])
            ax[iax].set_xlabel(r'$\lambda-\lambda_0$ [\AA]')
            iax+= 1
    ax[0].legend(loc='lower right')

    scl = [1.e-3, 1.e-5, 1.e-5, 1.e-3, 1.e-3, 180./3.1415926]
    var = [m.temp, m.vlos, m.vturb, m.Bln, m.Bho, m.azi]
    tau = m.ltau[0,0,0]
    ma = [10, 5, 5, 2, 3, 180]
    mi = [3.,-5, 0, -2, 0, 0]

    
    iv = 0
    for jj in range(2):
        for ii in range(3):
            ax[iax].plot(tau, var[iv][0,yy,xx]*scl[iax-4], 'k-')
            ax[iax].set_ylim(mi[iax-4], ma[iax-4])
            ax[iax].set_xlim(-6.5, 0.0)
            ax[iax].set_ylabel(ytit[iax])
            ax[iax].set_xlabel(r'$\log \tau_{500}$')

            iax+=1
            iv+=1

    f.subplots_adjust(left=0.07, right=0.98, top=0.98, bottom=0.07)
    f.savefig('fig_inv_xx={0:02d}_yy={1:02d}.pdf'.format(xx,yy), format='pdf', dpi=300)
    
if __name__ == "__main__":

    plt.close("all")

    # load spectra and output atmos
    m = sp.model('atmosout_cycle1.nc')
    o = sp.profile('observed.nc')
    s = sp.profile('synthetic.nc')

    for yy in range(2):
        for xx in range(2):
            plot_pix(m, o, s, yy, xx)
