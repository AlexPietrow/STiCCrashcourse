#!/usr/bin/env python3
"""
Prepare CRISP Ca II 8542 observed profiles for STiC.

What this does (unchanged behavior):
  1) Read wavelength and Stokes data from FITS.
  2) Shift wavelengths by a chosen center (w[10]) and build a fine, uniform grid
     with Δλ = 0.035 Å that covers all observed points.
  3) Map each observed wavelength to the nearest index on that fine grid.
  4) Create a `sparsetools.profile` container and place the observed samples
     at those mapped indices (leaving the rest as gaps).
  5) Set weights: large weights (ignore) everywhere, realistic noise at observed
     samples.
  6) Fetch quiet-Sun continuum Ic (CGS) from the FTS atlas for STiC normalization.
  7) Build a CRISP dual-etalon instrumental profile and save it as 8542.nc.
  8) Save:
        - observed.nc
        - observed_line_pos.fits (the index map)
     and print the `region = ...` line for input.cfg.

IMPORTANT: Indexing and array shapes are kept exactly as in your working file.
"""

import os
import sys
import numpy as np

# ---------------------------------------------------------------------------
# Make sure the shared pythontools are importable (kept identical in spirit)
# ---------------------------------------------------------------------------
try:
    HERE = os.path.dirname(__file__)     # running as a script
except NameError:
    HERE = os.getcwd()                   # running in IPython

PYTOOLS = os.path.abspath(os.path.join(HERE, "../../pythontools/py2"))
if os.path.isdir(PYTOOLS) and (PYTOOLS not in sys.path):
    sys.path.append(PYTOOLS)

import sparsetools as sp
import mfits
import crisp
import satlas as sa

# ---------------------------------------------------------------------------
# 1) Read FITS data
# ---------------------------------------------------------------------------
wav_file = "CaII_8542_fullstokes_2x2pix_wav.fits"
dat_file = "CaII_8542_fullstokes_2x2pix_data.fits"

if not os.path.isfile(wav_file):
    raise FileNotFoundError(f"Missing {wav_file}")
if not os.path.isfile(dat_file):
    raise FileNotFoundError(f"Missing {dat_file}")

w = mfits.readfits(wav_file)     # shape [N_wav] (Å)
d = mfits.readfits(dat_file)     # shape [ny, nx, N_wav, 4]

# light sanity checks (do not change behavior)
if d.ndim != 4 or d.shape[-1] != 4:
    raise ValueError(f"Expected data shape [ny, nx, N_wav, 4], got {d.shape}")
if w.ndim != 1 or w.size != d.shape[2]:
    raise ValueError("Wavelength vector size must match data's N_wav axis.")

# ---------------------------------------------------------------------------
# 2) Choose center wavelength and build a fine, uniform grid (Δλ = 0.035 Å)
#    NOTE: we keep the original convention: take w[10] as center cw.
# ---------------------------------------------------------------------------
cw = w[10]            # original choice retained
w_shift = w - cw      # work in a shifted frame

dw = 0.035            # 35 mÅ
# number of points needed to cover the observed span, +5 guard points
nw_fine = int((w_shift[-1] - w_shift[0]) / dw + 0.1) + 5
w_fine_shift = (np.arange(nw_fine, dtype="float64") - nw_fine // 2) * dw
w_fine = w_fine_shift + cw

# ---------------------------------------------------------------------------
# 3) Map each observed wavelength to the nearest index in the fine grid
# ---------------------------------------------------------------------------
idx = np.zeros(w.size, dtype="int32")
for jj in range(w.size):
    idx[jj] = np.argmin(np.abs(w_fine_shift - w_shift[jj]))

# ---------------------------------------------------------------------------
# 4) Create the sparsetools profile and place observations at mapped indices
#    NOTE: we keep the original indexing exactly:
#          p.dat[0, :, :, idx[ii], :] = d[:, :, ii, :]
#    so we preserve the same axis order the code expects.
# ---------------------------------------------------------------------------
ny, nx, nw_obs, nstokes = d.shape
p = sp.profile(nx=nx, ny=ny, nw=w_fine.size, ns=nstokes)
p.wav[:] = w_fine

for ii in range(w.size):
    # Keep the exact working assignment:
    # dat shape is (nt, ny, nx, nw, ns) in this build; we fill nt=0
    p.dat[0, :, :, idx[ii], :] = d[:, :, ii, :]

# ---------------------------------------------------------------------------
# 5) Set weights: ignore everywhere by default, real noise at observed samples
#    (unchanged values)
# ---------------------------------------------------------------------------
p.weights[:, :] = 1.0e30      # huge weights = ignored in χ²
p.weights[idx, :] = 2.0e-3    # noise level ~2e-3 of Ic at observed points

# Optionally boost polarization (left at 1.0 == no change in your original code)
p.weights[idx, 1:3] /= 1.0    # Q & U
p.weights[idx, 3]   /= 1.0    # V

# ---------------------------------------------------------------------------
# 6) Quiet-Sun continuum Ic in CGS (for STiC normalization)
# ---------------------------------------------------------------------------
fts = sa.satlas()
_, _, c = fts.getatlas(8542.0, 8542.02, cgs=True)  # c[0] is Ic (CGS)

# ---------------------------------------------------------------------------
# 7) Build CRISP dual-etalon IP and save as 8542.nc (same parameters)
# ---------------------------------------------------------------------------
fpi = crisp.crisp(8542.0)
ntw = 21
tw = (np.arange(ntw) - ntw // 2) * dw
tr = fpi.dual_fpi(tw, erh=-0.01)

# Keep exactly the same call signature (empty abscissa list):
sp.writeInstProf("8542.nc", tr, [])

# ---------------------------------------------------------------------------
# 8) Save outputs + print region line for input.cfg (unchanged formatting)
# ---------------------------------------------------------------------------
p.write("observed.nc")

print("\nCopy the following region info in your input file:")
print("region = {0:13.5f}, {1:7.5}, {2:4d}, {3:e}, spectral, 8542.nc"
      .format(w_fine[0], dw, w_fine.size, c[0]))
print(" ")

# Store observed→fine-grid indices for plotting/debugging
mfits.writefits("observed_line_pos.fits", idx)
