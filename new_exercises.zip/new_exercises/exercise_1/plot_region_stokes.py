import sys, os

try:
    base = os.path.dirname(__file__)  # ran as .py
except NameError:
    base = os.getcwd()  # ran in ipython

sys.path.append(os.path.abspath(os.path.join(base, "../../pythontools/py2")))

import numpy as np
import matplotlib.pyplot as plt
import sparsetools as sp

# -----------------------------
# User selection (pick one)
# -----------------------------
region_idx = 0              # OPTION A: choose by index (0-based)
target_wavelength = None    # OPTION B: set e.g. 2796.0 (Å) to pick nearest region

# -----------------------------
# Load and select region
# -----------------------------
syn = sp.profile("synthetic.nc").splitRegions()

def pick_region_by_wavelength(regions, target_A):
    """Return (region, index) with central wavelength nearest to target_A."""
    centers = [r.wav[len(r.wav)//2] for r in regions]
    i = int(np.argmin(np.abs(np.array(centers) - target_A)))
    return regions[i], i

if target_wavelength is not None:
    region, region_idx = pick_region_by_wavelength(syn, float(target_wavelength))
else:
    region = syn[region_idx]

wav = region.wav
# dat shape: [nx, ny, nt, nlambda, stokes] — we’ll just take [0,0,0,:,S]
I = region.dat[0, 0, 0, :, 0]
Q = region.dat[0, 0, 0, :, 1]
U = region.dat[0, 0, 0, :, 2]
V = region.dat[0, 0, 0, :, 3]

# -----------------------------
# Plot: 2×2 grid (I, Q, U, V)
# -----------------------------
fig, axes = plt.subplots(2, 2, figsize=(8, 6), sharex=True)
(axI, axQ), (axU, axV) = axes

# --- Plot each Stokes ---
axI.plot(wav, I, color="black")
axI.set_title("Stokes I")
axI.set_ylabel("Intensity")

axQ.plot(wav, Q, color="black")
axQ.set_title("Stokes Q")
axQ.set_ylabel("Intensity")

axU.plot(wav, U, color="black")
axU.set_title("Stokes U")
axU.set_ylabel("Intensity")
axU.set_xlabel("Wavelength [Å]")

axV.plot(wav, V, color="black")
axV.set_title("Stokes V")
axV.set_ylabel("Intensity")
axV.set_xlabel("Wavelength [Å]")

# --- Styling ---
for ax in (axI, axQ, axU, axV):
    ax.tick_params(axis="x", rotation=45)

fig.suptitle(f"Region {region_idx+1}", y=0.98)
fig.tight_layout()
plt.savefig(f"stokes_region_{region_idx+1}.pdf")
plt.show()
