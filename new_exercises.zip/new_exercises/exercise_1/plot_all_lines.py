import sys, os

try:
    base = os.path.dirname(__file__) #ran as .py
except NameError:
    base = os.getcwd() #ran in ipython 

sys.path.append(os.path.abspath(os.path.join(base, "../../pythontools/py2")))

import numpy as np
import matplotlib.pyplot as plt
import sparsetools as sp
import math

# Load STiC synthetic output and split into regions
syn = sp.profile("synthetic.nc").splitRegions()
n = len(syn)
print(f"Found {n} spectral regions")

# Choose a compact grid automatically (≈ square)
cols = math.ceil(math.sqrt(n))
rows = math.ceil(n / cols)

fig, axes = plt.subplots(rows, cols, figsize=(4*cols, 3*rows), sharex=False, sharey=False)
axes = np.atleast_2d(axes)

for i, region in enumerate(syn):
    r = i // cols
    c = i % cols
    ax = axes[r, c]

    wav = region.wav
    I = region.dat[0, 0, 0, :, 0]  # Stokes I

    ax.plot(wav, I, color="black")
    ax.set_xlabel("Wavelength [Å]")
    ax.set_ylabel("Intensity")
    ax.tick_params(axis="x", rotation=45)

# Hide any empty panels if grid > n
for j in range(n, rows*cols):
    r = j // cols
    c = j % cols
    fig.delaxes(axes[r, c])

fig.suptitle("STiC Synthetic Spectra — Stokes I", y=0.995)
fig.tight_layout()
plt.savefig("synthetic_collage.pdf")
plt.show()
