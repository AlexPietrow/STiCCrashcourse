import numpy as np
import matplotlib.pyplot as plt

# Load the FALC model text file (same one used in prepare_input_model.py)
fal = np.loadtxt("falc_cgs.txt")

z      = fal[:,0]  # geometric height [cm or km depending on file]
temp   = fal[:,1]  # temperature [K]
pgas   = fal[:,4]  # gas pressure [dyn/cm^2]

fig, ax1 = plt.subplots(figsize=(6,4))

# --- Temperature on the left y-axis ---
color = "tab:red"
ax1.set_xlabel("Height [km]")   # if your z is in km
ax1.set_ylabel("Temperature [kK]", color=color)
ax1.plot(z, temp/1000, color=color, label="Temperature")
ax1.tick_params(axis="y", labelcolor=color)
ax1.set_ylim(0,20)

# --- Pressure on the right y-axis ---
ax2 = ax1.twinx()
color = "tab:blue"
ax2.set_ylabel("Gas pressure [dyn/cm²]", color=color)
ax2.semilogy(z, pgas, color=color, label="Pressure")  # semilog for clarity
ax2.tick_params(axis="y", labelcolor=color)

# --- Vertical line at x=6e7 ---
ax1.axvline(6e7, color="k", linestyle="--", linewidth=1)
ax1.axvline(2.14e8, color="k", linestyle="--", linewidth=1)

plt.title("FALC Atmosphere: Temperature and Pressure")
fig.tight_layout()
plt.savefig('falc.pdf')
plt.show()
