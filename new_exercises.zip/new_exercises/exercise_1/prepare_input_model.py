#!/usr/bin/env python3
"""
Build a small STiC model from the FALC atmosphere and compute tau5000.

What this script does:
1) Read FALC from 'falc_cgs.txt' (z, T, v_los, v_turb, p_gas, n_e).
2) Create a 2x2 pixel model container with 1 time step.
3) Fill model fields (z, T, v, etc.) and set a simple constant magnetic field.
4) Compute log10(tau_500) by integrating the continuum opacity at 5000 Å.
5) Save the model to 'FALC.nc'.

Assumptions:
- Units in falc_cgs.txt are CGS (z in cm, T in K, p_gas in dyn/cm^2, n_e in cm^-3).
- Opacity routine eos.contOpacity expects (T, p_gas, P_e, lambda[Å]).
- The vertical coordinate z increases upward; we integrate using |dz|.
"""

import sys, os

try:
    base = os.path.dirname(__file__) #ran as .py
except NameError:
    base = os.getcwd() #ran in ipython 

sys.path.append(os.path.abspath(os.path.join(base, "../../pythontools/py2")))

import numpy as np
import sparsetools as sp
import witt as w

# --------------------------- Constants & settings -----------------------------

REF_WAVELENGTH_ANGSTROM = 5000.0   # reference wavelength for tau_500
NX, NY, NT = 2, 2, 1               # small demo grid (2x2, single snapshot)
FALC_PATH = "falc_cgs.txt"         # input atmosphere (CGS units)
OUTPUT_PATH = "FALC.nc"            # STiC model output

# ----------------------------- Core functions --------------------------------

def compute_log10_tau500(model: sp.model) -> None:
    """
    Fill model.ltau with tau500 by integrating continuum opacity
    at 5000 Å from top to bottom (trapezoidal rule in depth).

    Parameters
    ----------
    model : sp.model
        STiC model container with fields:
        - temp, pgas, nne [4D: (t,y,x,depth)]
        - z [same shape], monotonic in depth
        - ltau [same shape] will be written in-place

    Notes
    -----
    We integrate tau as:
        tau[i] = tau[i-1] + 0.5 * (kappa[i-1] + kappa[i]) * |dz|
    starting from i=1 with tau[0] = 0. After integrating tau, we offset it so
    that the top layers remain positive and take log10.
    """
    eos = w.witt()                # equation-of-state helper from 'witt'
    wav = [REF_WAVELENGTH_ANGSTROM]

    # Precompute electron pressure Pe = k_B * T * n_e  (CGS)
    # eos.BK is Boltzmann's constant in CGS according to witt
    Pe = model.temp * eos.BK * model.nne

    # Initialize tau to zero everywhere
    model.ltau[...] = 0.0

    for tt in range(model.nt):
        for yy in range(model.ny):
            for xx in range(model.nx):
                # --- Seed opacity at the first depth point
                kappa_prev = eos.contOpacity(
                    model.temp[tt, yy, xx, 0],
                    model.pgas[tt, yy, xx, 0],
                    Pe[tt, yy, xx, 0],
                    wav
                )

                # --- Integrate downwards (increasing depth index)
                for ii in range(1, model.ndep):
                    kappa = eos.contOpacity(
                        model.temp[tt, yy, xx, ii],
                        model.pgas[tt, yy, xx, ii],
                        Pe[tt, yy, xx, ii],
                        wav
                    )
                    dz = abs(model.z[tt, yy, xx, ii] - model.z[tt, yy, xx, ii-1])

                    model.ltau[tt, yy, xx, ii] = (
                        model.ltau[tt, yy, xx, ii-1] + 0.5 * (kappa_prev + kappa) * dz
                    )
                    kappa_prev = kappa

                # --- Shift and log: keep tau strictly positive before log10
                # Extrapolate a small positive offset from first two layers
                # (guards against log(0) and makes top layers readable on log scale)
                tau1 = model.ltau[tt, yy, xx, 1]
                tau2 = model.ltau[tt, yy, xx, 2] if model.ndep > 2 else tau1 * 1.5
                # offset ~ tau1^2 / tau2 (geometric trend)
                offset = np.exp(2.0 * np.log(max(tau1, 1e-300)) - np.log(max(tau2, 1e-300)))
                safe_tau = offset + np.maximum(model.ltau[tt, yy, xx, :], 0.0)
                model.ltau[tt, yy, xx, :] = np.log10(np.maximum(safe_tau, 1e-300))


def load_falc(path: str) -> np.ndarray:
    """
    Load the FALC atmosphere table.

    Returns
    -------
    fal : (ndep, 6) ndarray
        Columns: z, T, v_los, v_turb, p_gas, n_e
    """
    fal = np.loadtxt(path)
    if fal.ndim != 2 or fal.shape[1] < 6:
        raise ValueError(
            f"Expected at least 6 columns in {path} (z, T, v_los, v_turb, p_gas, n_e); "
            f"got shape {fal.shape}"
        )
    return fal


def create_model_from_falc(fal: np.ndarray) -> sp.model:
    """
    Create and fill a STiC model from a FALC array.

    Parameters
    ----------
    fal : ndarray
        Columns: z, T, v_los, v_turb, p_gas, n_e

    Returns
    -------
    m : sp.model
        Populated model with simple constant magnetic field.
    """
    ndep = fal.shape[0]
    m = sp.model(nx=NX, ny=NY, ndep=ndep, nt=NT)

    # Fill the depth-dependent fields for all pixels at t=0
    for zz in range(ndep):
        m.z[0, :, :, zz]    = fal[zz, 0]
        m.temp[0, :, :, zz] = fal[zz, 1]
        m.vlos[0, :, :, zz] = fal[zz, 2]
        m.vturb[0, :, :, zz]= fal[zz, 3]
        m.pgas[0, :, :, zz] = fal[zz, 4]
        m.nne[0, :, :, zz]  = fal[zz, 5]

    # Simple constant magnetic field (same for all depths & pixels)
    m.Bln[:] = 400.0                          # longitudinal [G]
    m.Bho[:] = 650.0                          # horizontal  [G]
    m.azi[:] = 19.0 * np.pi / 180.0           # azimuth [rad]

    return m

# --------------------------------- Main --------------------------------------

if __name__ == "__main__":
    # 1) Load atmosphere table
    fal = load_falc(FALC_PATH)

    # 2) Create and fill the model
    m = create_model_from_falc(fal)

    # 3) Compute log10(tau_500)
    compute_log10_tau500(m)

    # 4) Save to disk
    m.write(OUTPUT_PATH)
    print(f"Model written to: {OUTPUT_PATH}")
