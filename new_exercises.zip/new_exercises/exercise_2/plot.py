#!/usr/bin/env python3
"""
Quick comparison of initial (FALC) and inverted atmospheres.

- Lightweight (no TeX, no heavy rcParams)
- Clear labels, legends, grids
- Reversed x-axis (log tau decreases upward)
- Safe paths + basic checks
"""

import os
import numpy as np
import matplotlib.pyplot as plt

try:
    # If run from the exercise_2 directory, this hits exercise_1/FALC.nc by default
    HERE = os.path.dirname(__file__)
except NameError:
    HERE = os.getcwd()

# ---- Paths (tweak if your files live elsewhere) ----
FALC_PATH = os.path.join(HERE, "../exercise_1/FALC.nc")
INV_PATH  = os.path.join(HERE, "atmosout_cycle1.nc")

# Optional: add pythontools if you need it
PYTOOLS = os.path.abspath(os.path.join(HERE, "../../pythontools/py2"))
if os.path.isdir(PYTOOLS) and PYTOOLS not in os.sys.path:
    os.sys.path.append(PYTOOLS)

import sparsetools as sp  # after path adjustment

def load_model(path, label):
    if not os.path.isfile(path):
        raise FileNotFoundError(f"{label} not found: {path}")
    return sp.model(path)

def main():
    # Load models
    mi = load_model(FALC_PATH, "FALC model (initial)")
    mo = load_model(INV_PATH,  "Inverted model (output)")

    # Shorthand (single pixel/time)
    lt_i = mi.ltau[0,0,0];  lt_o = mo.ltau[0,0,0]      # log(tau_500)
    T_i  = mi.temp[0,0,0]/1e3; T_o  = mo.temp[0,0,0]/1e3            # kK
    vlos_i = mi.vlos[0,0,0]/1e5; vlos_o = mo.vlos[0,0,0]/1e5         # km/s
    vt_i   = mi.vturb[0,0,0]/1e5; vt_o   = mo.vturb[0,0,0]/1e5       # km/s
    Bpar_i = mi.Bln[0,0,0]/1e3;  Bpar_o = mo.Bln[0,0,0]/1e3          # kG
    Bperp_i= mi.Bho[0,0,0]/1e3;  Bperp_o= mo.Bho[0,0,0]/1e3          # kG
    azi_i  = mi.azi[0,0,0]*180/np.pi; azi_o = mo.azi[0,0,0]*180/np.pi# deg

    # Figure: 2 rows × 3 columns
    fig, ax = plt.subplots(2, 3, figsize=(9, 5), sharex=False)
    (axT, axVlos, axVt), (axBpar, axBperp, axAzi) = ax

    def style(ax, ylab, ymin=None, ymax=None):
        ax.set_xlabel(r"$\log\,\tau_{500}$")
        ax.set_ylabel(ylab)
        if ymin is not None or ymax is not None:
            ax.set_ylim(ymin, ymax)
        # log(tau) often shown decreasing to the right -> reverse axis
        ax.invert_xaxis()

    # Temperature
    axT.plot(lt_i, T_i, color="black",  lw=1.2, label="Initial")
    axT.plot(lt_o, T_o, color="tomato", lw=1.2, label="Inverted")
    style(axT, "T [kK]", 3.5, 15)
    axT.legend(frameon=False)

    # v_los
    axVlos.plot(lt_i, vlos_i, color="black",  lw=1.2)
    axVlos.plot(lt_o, vlos_o, color="tomato", lw=1.2)
    style(axVlos, r"$v_{\mathrm{LOS}}$ [km s$^{-1}$]", -5, 5)

    # v_turb
    axVt.plot(lt_i, vt_i, color="black",  lw=1.2)
    axVt.plot(lt_o, vt_o, color="tomato", lw=1.2)
    style(axVt, r"$v_{\mathrm{turb}}$ [km s$^{-1}$]", 0, 8)

    # B_parallel
    axBpar.plot(lt_i, Bpar_i, color="black",  lw=1.2)
    axBpar.plot(lt_o, Bpar_o, color="tomato", lw=1.2)
    style(axBpar, r"$B_{\parallel}$ [kG]", 0, 1)

    # B_perp
    axBperp.plot(lt_i, Bperp_i, color="black",  lw=1.2)
    axBperp.plot(lt_o, Bperp_o, color="tomato", lw=1.2)
    style(axBperp, r"$B_{\perp}$ [kG]", 0, 1)

    # Azimuth
    axAzi.plot(lt_i, azi_i, color="black",  lw=1.2)
    axAzi.plot(lt_o, azi_o, color="tomato", lw=1.2)
    style(axAzi, r"Azimuth [deg]", 0, 45)

    fig.tight_layout()
    fig.savefig("fig_result_simple.pdf", dpi=200)
    plt.show()

if __name__ == "__main__":
    main()
