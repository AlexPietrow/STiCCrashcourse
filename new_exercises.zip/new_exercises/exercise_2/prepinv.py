#!/usr/bin/env python3
"""
Exercise 2: Build a noisy 'observation' from Exercise 1 and create
a simple initial model guess for the inversion.

Didactic goals:
- Understand how noise and weights affect inversions.
- See how multiple spectral regions are merged.
- Build a minimal initial model on a log(tau) grid.
"""

# -----------------------------
# Imports
# -----------------------------
import sys, os

try:
    base = os.path.dirname(__file__) #ran as .py
except NameError:
    base = os.getcwd() #ran in ipython 

sys.path.append(os.path.abspath(os.path.join(base, "../../pythontools/py2")))


import numpy as np
import sparsetools as sp
import mathtools as mt  # STiC's bezier3, etc.

# -----------------------------
# User-tunable parameters
# -----------------------------
EX1_OUTPUT = "../exercise_1/synthetic.nc"  # source from Exercise 1
OBS_OUT    = "observed.nc"                  # noisy profiles written here
MODEL_OUT  = "modelin.nc"                   # initial guess model written here

# Noise level as a fraction of mean I (per region)
NOISE_FRAC_I = 2.0e-3

# Relative weights (smaller "noise" => larger weight)
WEIGHT_SCALE_Q_U = 1/8.0   # i.e., 8× weight vs I
WEIGHT_SCALE_V   = 1/4.0   # i.e., 4× weight vs I

# Initial model grid in log10(tau_500)
LTAU_MIN, LTAU_MAX, DLTAU = -8.0, 1.0, 0.18

# Initial temperature control points (log(tau), T[K]) for Bezier interpolation
ILTAU_CTRL = np.float32([-8.0, -6.8, -5.5, -4.0, -2.0, 1.0])
ITEMP_CTRL = np.float32([20000., 10000.,  6000.,  4000., 5000., 7000.])

# Other initial-guess constants
VTURB_CMS = 2.0e5  # microturbulent velocity [cm/s]
BLN_G     = 200.0  # longitudinal B [G]
BHO_G     = 300.0  # transverse  B [G]
AZI_RAD   = 10.0 * np.pi / 180.0
PGAS_CGS  = 0.3    # crude placeholder (code will recompute if asked)


# -----------------------------
# Helpers
# -----------------------------
def log(msg: str):
    print(f"[INFO] {msg}")

def make_ltau_grid(lmin, lmax, dl):
    ntau = int((lmax - lmin) / dl + 1)
    ltau = np.linspace(lmin, lmax, ntau, dtype=np.float32)
    return ltau

# -----------------------------
# 1) Load synthetic profiles and extract a single pixel
# -----------------------------
log(f"Reading synthetic profiles from: {EX1_OUTPUT}")
# Take pixel (0,0); keeps all spectral regions
regions = sp.profile(EX1_OUTPUT).extractPix(x0=0, x1=1, y0=0, y1=1).splitRegions()
assert len(regions) > 0, "No regions found. Check the input path."

log(f"Found {len(regions)} spectral region(s).")

# -----------------------------
# 2) Add noise & set weights
# -----------------------------
rng = np.random.default_rng(seed=42)  # reproducible noise for teaching
for r, reg in enumerate(regions, start=1):
    # Mean continuum-ish intensity (use average over lambda of Stokes I)
    imean = reg.averageSpectrum()[:, 0].mean()
    sigma_I = NOISE_FRAC_I * imean

    # Set weights = effective noise per Stokes (smaller is stronger weight)
    reg.weights[:, :] = sigma_I
    reg.weights[:, 1:3] *= WEIGHT_SCALE_Q_U  # Q, U heavier
    reg.weights[:, 3]   *= WEIGHT_SCALE_V    # V heavier

    # Add Gaussian noise to the data cube (same sigma across Stokes here)
    reg.dat += rng.normal(loc=0.0, scale=sigma_I, size=reg.dat.shape)

    log(f"Region {r}: <I>≈{imean:.3e}, σ_I={sigma_I:.3e} "
        f"| weight scales → Q/U×{1/WEIGHT_SCALE_Q_U:.0f}, V×{1/WEIGHT_SCALE_V:.0f}")

# -----------------------------
# 3) Merge regions and save as "observed" dataset
# -----------------------------
merged = regions[0]
for rr in regions[1:]:
    merged = merged + rr

log(f"Writing noisy observation → {OBS_OUT}")
merged.write(OBS_OUT)

# -----------------------------
# 4) Build a simple initial model on log(tau) grid and save
# -----------------------------
ltau = make_ltau_grid(LTAU_MIN, LTAU_MAX, DLTAU)
ndep = ltau.size

# Interpolate a smooth temperature stratification (monotonic Bezier curve)
temp_strat = mt.bezier3(ILTAU_CTRL, ITEMP_CTRL, ltau).astype(np.float32)

# Create model container (match observation’s spatial size)
m = sp.model(nx=merged.nx, ny=merged.ny, ndep=ndep, nt=1)

# Fill stratifications (same for all pixels for this initial guess)
for k in range(ndep):
    m.ltau[:, :, :, k]  = ltau[k]
    m.temp[:, :, :, k]  = temp_strat[k]
    m.vturb[:, :, :, k] = VTURB_CMS
    m.Bln[:, :, :, k]   = BLN_G
    m.Bho[:, :, :, k]   = BHO_G
    m.azi[:, :, :, k]   = AZI_RAD
    m.pgas[:, :, :, k]  = PGAS_CGS  # placeholder; STiC can recompute hydro/N_e

log(f"Initial model grid: ntau={ndep} from {LTAU_MIN} to {LTAU_MAX} (Δ={DLTAU})")
log(f"Writing initial model guess → {MODEL_OUT}")
m.write(MODEL_OUT)

log("Done. Next: run STiC in inversion mode using observed.nc + modelin.nc.")
