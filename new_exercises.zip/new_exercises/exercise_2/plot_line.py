#!/usr/bin/env python3
"""
Plot Stokes I/Q/U/V for a chosen spectral region, overlaying observed vs fit.

- Select by region index OR target wavelength (Å)
- Lightweight: no LaTeX, quick start
- Optional continuum normalization
- Safe paths & fallback if inversion file not found
"""

import os, sys
import numpy as np
import matplotlib.pyplot as plt

# -----------------------------
# User options
# -----------------------------
region_idx        = 4            # choose by index (0-based) if target_wavelength=None
target_wavelength = None         # e.g. 2796.0 to auto-pick nearest region center
normalize_to_Ic   = True         # divide Stokes by local Ic (observed Ic)
obs_file          = "observed.nc"
fit_file_try      = "profilesout_cycle1.nc"  # STiC inversion output
fit_file_fallback = "synthetic.nc"           # fallback if the above doesn't exist

# -----------------------------
# Find repo pythontools (optional)
# -----------------------------
try:
    HERE = os.path.dirname(__file__)
except NameError:
    HERE = os.getcwd()

PYTOOLS = os.path.abspath(os.path.join(HERE, "../../pythontools/py2"))
if os.path.isdir(PYTOOLS) and PYTOOLS not in sys.path:
    sys.path.append(PYTOOLS)

import sparsetools as sp  # provided with STiC tools

# -----------------------------
# Helpers
# -----------------------------
def load_profile_split(path, label):
    if not os.path.isfile(path):
        raise FileNotFoundError(f"{label} not found: {path}")
    return sp.profile(path).splitRegions()

def pick_by_wavelength(regions, target_A):
    centers = [r.wav[len(r.wav)//2] for r in regions]
    i = int(np.argmin(np.abs(np.array(centers) - target_A)))
    return regions[i], i, centers[i]

def extract_stokes(region):
    # dat shape: [nx, ny, nt, nlambda, stokes]
    data = region.dat[0, 0, 0]            # [nlambda, 4]
    wav  = region.wav                     # [nlambda]
    return wav, data[:,0], data[:,1], data[:,2], data[:,3]

def local_Ic(I):
    # simple continuum estimate: max over window
    return np.nanmax(I)

# -----------------------------
# Load observed + fit
# -----------------------------
obs_regions = load_profile_split(os.path.join(HERE, obs_file), "Observed profiles")

fit_path = os.path.join(HERE, fit_file_try)
if not os.path.isfile(fit_path):
    fit_path = os.path.join(HERE, fit_file_fallback)
fit_regions = load_profile_split(fit_path, "Fit profiles")

# -----------------------------
# Pick region
# -----------------------------
if target_wavelength is not None:
    obs_region, region_idx, picked = pick_by_wavelength(obs_regions, float(target_wavelength))
    # match the fit region by nearest center as well
    fit_region, _, _ = pick_by_wavelength(fit_regions, picked)
else:
    obs_region = obs_regions[region_idx]
    fit_region = fit_regions[min(region_idx, len(fit_regions)-1)]

# -----------------------------
# Extract and (optionally) normalize
# -----------------------------
w_obs, I_obs, Q_obs, U_obs, V_obs = extract_stokes(obs_region)
w_fit, I_fit, Q_fit, U_fit, V_fit = extract_stokes(fit_region)

if normalize_to_Ic:
    Ic = local_Ic(I_obs)
    if Ic == 0 or not np.isfinite(Ic):
        Ic = 1.0
    I_obs, Q_obs, U_obs, V_obs = I_obs/Ic, Q_obs/Ic, U_obs/Ic, V_obs/Ic
    I_fit, Q_fit, U_fit, V_fit = I_fit/Ic, Q_fit/Ic, U_fit/Ic, V_fit/Ic
    ylab = "Stokes / Ic"
else:
    ylab = "Intensity"

# -----------------------------
# Plot (2×2: I, Q, U, V)
# -----------------------------
fig, axes = plt.subplots(2, 2, figsize=(8, 6), sharex=True)
(axI, axQ), (axU, axV) = axes

def stylize(ax, label):
    ax.set_ylabel(label)

# I
axI.plot(w_obs, I_obs, "o", ms=2.5, label="obs", alpha=0.8)
axI.plot(w_fit, I_fit, "-", lw=1.4, label="fit")
stylize(axI, "I" + (f" ({ylab})" if ylab else ""))
axI.legend(frameon=False, ncol=2, fontsize=8)

# Q
axQ.plot(w_obs, Q_obs, "o", ms=2.5, alpha=0.8)
axQ.plot(w_fit, Q_fit, "-", lw=1.4)
stylize(axQ, "Q")

# U
axU.plot(w_obs, U_obs, "o", ms=2.5, alpha=0.8)
axU.plot(w_fit, U_fit, "-", lw=1.4)
stylize(axU, "U")
axU.set_xlabel("Wavelength [Å]")

# V
axV.plot(w_obs, V_obs, "o", ms=2.5, alpha=0.8)
axV.plot(w_fit, V_fit, "-", lw=1.4)
stylize(axV, "V")
axV.set_xlabel("Wavelength [Å]")

for ax in (axI, axQ, axU, axV):
    ax.tick_params(axis="x", rotation=45)

fig.tight_layout()
outname = f"stokes_fit_region_{region_idx+1}.pdf"
fig.savefig(outname, dpi=200)
print(f"Saved {outname}")
plt.show()
